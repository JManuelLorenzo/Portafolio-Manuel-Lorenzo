package src;

/**
 *
 * @author ernesto
 */
public interface IConjunto {

    
    Conjunto union(Conjunto otroConjunto);

    Conjunto interseccion(Conjunto otroConjunto);
}
